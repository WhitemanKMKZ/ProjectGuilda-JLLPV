# Fluxograma do site LUMORA

```mermaid
flowchart TD
  A([Abrir o site]) --> H["Início<br/>hero, serviços, destaques, promoção"]
  H --> M{"Menu inferior"}
  M -->|Início| H
  M -->|Agendar| AG
  M -->|Perucas| PE
  M -->|Carrinho| CA

  H -->|Escolher serviço| S1["Serviço selecionado"] --> AG
  H -->|Aproveitar Oferta| P1["Aplica 20% em Hidratação Profunda"] --> AG
  H -->|"+ em peruca em destaque"| ADD

  H -.->|Botão Entrar| AU
  subgraph AUTH["Entrar / Cadastrar"]
    AU{"Já tem conta?"}
    AU -->|Sim| LG["Login: e-mail e senha"]
    AU -->|Não| CD["Cadastro: nome, e-mail, senha"]
    CD --> DN{"Sou a dona do salão?"}
    DN -->|Sim| OW["Perfil de dona"]
    DN -->|Não| CL["Perfil de cliente"]
    LG --> V{"Dados corretos?"}
    V -->|Não| ER["Mostra erro"] --> LG
    V -->|Sim| OK
    OW --> OK
    CL --> OK
    OK(["Usuária logada"])
  end

  subgraph AGENDA["Agendar horário"]
    AG["Escolher serviço"] --> DT["Escolher data"]
    DT --> HR["Escolher horário livre"]
    HR --> CF["Confirmar agendamento"]
    CF --> L1{"Logada?"}
    L1 -->|Não| AU
    L1 -->|Sim| SV["Salva agendamento"]
    SV --> MY["Lista Meus agendamentos"]
    MY -->|Cancelar| RM["Remove agendamento"] --> MY
    SV --> OD{"É dona?"}
    OD -->|Sim| PN["Painel com todos os agendamentos"]
  end

  subgraph LOJA["Perucas e carrinho"]
    PE["Catálogo de perucas"] --> FI["Filtrar: Todas, Lisas, Cacheadas, Crespas, Coloridas"]
    FI --> ADD["Adicionar ao carrinho"]
    PE --> ADD
    ADD --> CA["Carrinho"]
    CA --> E{"Tem itens?"}
    E -->|Não| PE
    E -->|Sim| Q["Ajustar quantidades"]
    Q --> FN["Finalizar compra"]
    FN --> L2{"Logada?"}
    L2 -->|Não| AU
    L2 -->|Sim| FIM(["Pedido realizado, carrinho esvaziado"])
  end
```
